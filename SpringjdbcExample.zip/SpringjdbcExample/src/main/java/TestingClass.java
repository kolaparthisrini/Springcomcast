import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import om.comcast.jdbc.JdbcTemplateImpl;
import om.comcast.beans.Employee;
public class TestingClass {

	
	public static void main(String...a)
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");  
	      
		JdbcTemplateImpl dao=(JdbcTemplateImpl)ctx.getBean("ed");  
	    int status=dao.saveEmployee(new Employee(121,"Jessica",1000));  
	    //System.out.println(status); 
	    for(Employee f: dao.getEmployees())
	    System.out.println(f.getFullname());
	}
}
