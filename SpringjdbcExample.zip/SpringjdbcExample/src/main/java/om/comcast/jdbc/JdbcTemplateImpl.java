package om.comcast.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import om.comcast.beans.Employee;

public class JdbcTemplateImpl {

	private JdbcTemplate jdbctemplate = null;

	/**
	 * @return the jdbctemplate
	 */
	public JdbcTemplate getJdbctemplate() {
		return jdbctemplate;
	}

	/**
	 * @param jdbctemplate
	 *            the jdbctemplate to set
	 */
	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}

	public int saveEmployee(Employee e) {
		String query = "insert into employee values('" + e.getId() + "','" + e.getFullname() + "','" + e.getSalary()
				+ "')";
		return jdbctemplate.update(query);
	}

	public List<Employee> getEmployees() {
		return jdbctemplate.query("select * from employee", new RowMapper<Employee>() {

			public Employee mapRow(ResultSet rs, int rownum) throws SQLException {
				Employee e = new Employee();
				e.setId(rs.getInt(1));
				e.setFullname(rs.getString(2));
				return e;
			}

		}

		);
	}

}
