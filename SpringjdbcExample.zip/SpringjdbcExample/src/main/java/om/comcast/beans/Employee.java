package om.comcast.beans;

public class Employee {
	private int id;  
	private String fullname;  
	private float salary;
	/**
	 * @return the id
	 */
	public Employee(){}
	public Employee(int id,String fullname,float salary){
		this.id=id;
		this.fullname=fullname;
		this.salary=salary;
	}
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the fullname
	 */
	public String getFullname() {
		return fullname;
	}
	/**
	 * @param fullname the fullname to set
	 */
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	/**
	 * @return the salary
	 */
	public float getSalary() {
		return salary;
	}
	/**
	 * @param salary the salary to set
	 */
	public void setSalary(float salary) {
		this.salary = salary;
	} 
}
