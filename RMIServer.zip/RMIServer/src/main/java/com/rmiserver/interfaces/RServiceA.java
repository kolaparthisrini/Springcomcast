package com.rmiserver.interfaces;

public interface RServiceA {
    public String addNumbers(int val1, int val2);
}