package com.rmiserver.io;

import org.springframework.stereotype.Service;

import com.rmiserver.interfaces.RServiceA;
 
@Service
public class MServiceA implements RServiceA {
 
    public String addNumbers(int val1, int val2) {
         
        int sum = val1 + val2;
        return "The SUM is "+sum;
    }
 
}