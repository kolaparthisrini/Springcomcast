package com.rmiserver.io;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.rmi.RmiServiceExporter;

import com.rmiserver.interfaces.RServiceA;
 

@Configuration
@ComponentScan("com.rmiserver.*")
public class CspringContext {
 
    @Bean
    @Autowired
    public RmiServiceExporter rmiServiceExporter (RServiceA service) {
           
        RmiServiceExporter exporter = new RmiServiceExporter();
         
        exporter.setServiceName("ServiceA");
        exporter.setService(service);
        exporter.setServiceInterface(RServiceA.class);
        //exporter.setRegistryHost("localhost");
        exporter.setRegistryPort(4400);
         
        return exporter;
    }
     
}