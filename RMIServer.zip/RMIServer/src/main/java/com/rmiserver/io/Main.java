package com.rmiserver.io;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


 
public class Main {
    public static void main(String [] arg) {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(CspringContext.class);
         
         
    }
}
