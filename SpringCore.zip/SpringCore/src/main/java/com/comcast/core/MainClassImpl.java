package com.comcast.core;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class MainClassImpl {

	public static void main(String... a) {

		ApplicationContext ctx1 = new ClassPathXmlApplicationContext("beans2.xml");
		Cat bn = (Cat) ctx1.getBean("cat");
        System.out.println(bn.getName());
	}
}
