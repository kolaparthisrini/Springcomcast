package com.comcast;

@Controller 
public class Hello { 
@RequestMapping("/") 
    public String display() 
    { 
        return "hello"; 
    }    
}