package com.comcast.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.rmi.RmiProxyFactoryBean;

import com.rmiserver.interfaces.RServiceA;

@Configuration
@ComponentScan("com.example.*")
public class SContextConfig {
 
    @Bean
    public RmiProxyFactoryBean rmiProxy() {
        RmiProxyFactoryBean proxy = new RmiProxyFactoryBean();
         
        proxy.setServiceUrl("rmi://localhost:4400/ServiceA");
        proxy.setServiceInterface(RServiceA.class);
        return proxy;
    }
}