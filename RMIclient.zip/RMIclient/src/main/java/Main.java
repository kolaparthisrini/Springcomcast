import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.comcast.config.SContextConfig;
import com.rmiserver.interfaces.RServiceA;

public class Main {
    public static void main(String [] arg) {
         AnnotationConfigApplicationContext context =               
                 new AnnotationConfigApplicationContext(SContextConfig.class);
          
         RServiceA service = context.getBean(RServiceA.class);
          
         System.out.println(service.addNumbers(10, 20));
         
         
    }
}