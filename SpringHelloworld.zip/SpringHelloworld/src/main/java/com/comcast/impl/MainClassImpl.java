package com.comcast.impl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.comcast.bean.BeanCollection;
import com.comcast.bean.EmployeeConstructor;
import com.comcast.bean.MyBean;
import com.comcast.bean.OrderBean;

public class MainClassImpl {

	public static void main(String... a) {

		ApplicationContext ctx1 = new ClassPathXmlApplicationContext("beans.xml");
		MyBean bn = (MyBean) ctx1.getBean("myname");
		bn.display();
		BeanCollection bn1 = (BeanCollection) ctx1.getBean("col");
		System.out.println(bn1.getMp());
		System.out.println(bn1.getSt());
		EmployeeConstructor bn2 = (EmployeeConstructor) ctx1.getBean("const");
		bn2.show();
		//================
		OrderBean employee = (OrderBean)ctx1.getBean("em");
		 
        System.out.println(employee.getFullName());

        System.out.println(employee.getDepartmentBean().getName());
	}
}
