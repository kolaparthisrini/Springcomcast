package com.comcast.bean;

public class EmployeeConstructor {
	
	int empno;
	String name;
	public EmployeeConstructor(int empno,String name)
	{
		this.empno=empno;
		this.name = name;
	}
public void show()
{
	System.out.println("Empno: "+this.empno+".."+this.name);
}
}
