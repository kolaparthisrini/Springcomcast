package com.comcast.bean;

public class OrderBean {
	 private DepartmentBean departmentBean = null;
	   
	  private String fullName;
	 
	  public DepartmentBean getDepartmentBean() {
	    return departmentBean;
	  }
	  public void setDepartmentBean(DepartmentBean departmentBean) {
	    this.departmentBean = departmentBean;
	  }
	  public String getFullName() {
	    return this.fullName;
	  }
	  public void setFullName(String fullName) {
	    this.fullName = fullName;
	  }
}
