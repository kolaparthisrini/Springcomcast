package com.comcast.bean;

public class MyBean {

	private String myname;

	public String getMyname() {
		return myname;
	}

	public void setMyname(String myname) {
		this.myname = myname;
	}
	
	public void display()
	{
		System.out.println(myname);
	}
}
