package com.comcast.bean;

import java.util.Map;
import java.util.Set;

public class BeanCollection {
	
	Set st;
	Map mp;
	public Set getSt() {
		return st;
	}
	public void setSt(Set st) {
		this.st = st;
	}
	public Map getMp() {
		return mp;
	}
	public void setMp(Map mp) {
		this.mp = mp;
	}
	

}
