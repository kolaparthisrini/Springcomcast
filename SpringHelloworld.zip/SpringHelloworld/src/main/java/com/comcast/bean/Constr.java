package com.comcast.bean;

public class Constr {
	
	private String uname;//class level variable
	Constr()
	{}
	
	Constr(String name)//name is method level variable 
	{
		uname=name;
	}
	
	public static void main(String...a)
	{
		Constr c= new Constr("Srini");
		System.out.println(c.uname);
	}

}
